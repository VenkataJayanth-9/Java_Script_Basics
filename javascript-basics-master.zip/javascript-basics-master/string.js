let name="John";
console.log(name);