// let count =0;
// while (count<5){
//     console.log(count);
//     count++;
// }
console.log(x);
var x = 5;
console.log(x);