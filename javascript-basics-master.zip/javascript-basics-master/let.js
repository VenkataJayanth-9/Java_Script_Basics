let person={
    name:"Alice",
    age:30,
    isStudent:false
};
console.log(person.name);
console.log(person)