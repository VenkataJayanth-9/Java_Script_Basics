const repeatedFunction  = () => {
    console.log('Repeated function executed!');
};
const intervalID = setInterval(repeatedFunction, 1000);//Executes every one second